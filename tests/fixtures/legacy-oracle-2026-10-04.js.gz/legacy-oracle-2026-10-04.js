"use strict";
/** One-time conversion only. Never loaded by index.html. Frozen schema 1/2 rules. */
const WorkLegacyV2 = (() => {
  // Frozen conversion source: assets/js/domain/time.js
  "use strict";
  /** time domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkTimeValues = (() => {
    const pad = (n) => String(n).padStart(2, "0");
    const dateKey = (d) =>
      d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
    // Business "today" uses China Standard Time; calendar cursors remain host-local noon dates.
    const businessDate = (d = new Date()) =>
      new Date(d.getTime() + 8 * 3600000).toISOString().slice(0, 10);
    const businessMinutes = (d = new Date()) => {
      const shifted = new Date(d.getTime() + 8 * 3600000);
      return shifted.getUTCHours() * 60 + shifted.getUTCMinutes();
    };
    const localDate = (k) => {
      const a = k.split("-").map(Number);
      return new Date(a[0], a[1] - 1, a[2], 12);
    };
    const validDate = (k) =>
      /^\d{4}-\d{2}-\d{2}$/.test(k) &&
      dateKey(localDate(k)) === k &&
      Number(k.slice(0, 4)) >= 1900;
    const timeMin = (t) =>
      /^([01]\d|2[0-3]):[0-5]\d$/.test(t || "")
        ? Number(t.slice(0, 2)) * 60 + Number(t.slice(3))
        : null;
    const breakMin = (t) => (t === "24:00" ? 1440 : timeMin(t));
    const formatMinutes = (m) =>
      m === null || m === undefined ? "—" : (m / 60).toFixed(2) + " h";
    const hours = (m) => Number((m / 60).toFixed(4));
    return {
      pad,
      dateKey,
      businessDate,
      businessMinutes,
      localDate,
      validDate,
      timeMin,
      breakMin,
      formatMinutes,
      hours,
    };
  })();

  // Frozen conversion source: assets/js/domain/state.js
  ("use strict");
  /** state domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkState = (() => {
    const DEFAULT_START = "08:00",
      DEFAULT_END = "17:30",
      DEFAULT_BREAKS = [
        { start: 720, end: 810 },
        { start: 1050, end: 1080 },
      ];
    const SCHEMA = 2,
      KEY = "worktime-local-v1";
    /** @returns {WorkStateData} A new state with independent arrays and day map. */
    function defaultState() {
      return {
        schemaVersion: SCHEMA,
        scheduleDefaultsVersion: 1,
        targetAverageMinutes: 120,
        overtimeRequirements: [120, null, null, null, null],
        oaUrl: "",
        settings: {
          employmentDate: "",
          workCity: "",
          configured: true,
          workStart: DEFAULT_START,
          workEnd: DEFAULT_END,
          standardMinutes: 480,
          breaks: DEFAULT_BREAKS.map((b) => ({ ...b })),
        },
        scheduleRanges: [],
        timeTemplates: [],
        days: {},
        imports: [],
      };
    }
    return {
      DEFAULT_START,
      DEFAULT_END,
      DEFAULT_BREAKS,
      SCHEMA,
      KEY,
      defaultState,
    };
  })();

  // Frozen conversion source: assets/js/domain/migrations.js
  ("use strict");
  /** Legacy schema-1 metadata migration. User settings always survive unchanged. */
  const WorkMigrations = (() => {
    const { DEFAULT_START, DEFAULT_END, DEFAULT_BREAKS } = WorkState;
    /** @param {WorkStateData} state Validated state; mutates missing defaults and metadata only. */
    function applyScheduleDefaults(state) {
      let changed = false;
      for (const [key, fallback] of [
        ["workStart", DEFAULT_START],
        ["workEnd", DEFAULT_END],
      ]) {
        if (!state.settings[key]) {
          state.settings[key] = fallback;
          changed = true;
        }
      }
      if (!Array.isArray(state.settings.breaks)) {
        state.settings.breaks = DEFAULT_BREAKS.map((rest) => ({ ...rest }));
        changed = true;
      }
      if (state.scheduleDefaultsVersion !== 1) {
        // Versionless backups may already contain intentional custom or empty breaks.
        state.scheduleDefaultsVersion = 1;
        changed = true;
      }
      return changed;
    }
    return { applyScheduleDefaults };
  })();

  // Frozen conversion source: assets/js/domain/calendar.js
  ("use strict");
  /** calendar domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkCalendar = (() => {
    const { dateKey, localDate } = WorkTimeValues;
    const holidays = {},
      makeups = new Set();
    const calendarSchedules = WorkTimeApp.data.calendars.schedules;
    const struggleDays = new Set(WorkTimeApp.data.struggleDays);
    for (const [year, schedule] of Object.entries(calendarSchedules)) {
      for (const [start, end, name] of schedule.off) {
        const date = localDate(year + "-" + start);
        while (dateKey(date) <= year + "-" + end) {
          holidays[dateKey(date)] = name;
          date.setDate(date.getDate() + 1);
        }
      }
      schedule.work.forEach((date) => makeups.add(year + "-" + date));
    }
    const calendarKnown = (date) =>
      Object.hasOwn(calendarSchedules, Number(date.slice(0, 4)));
    function calendarInfo(k, day = {}) {
      const weekend = [0, 6].includes(localDate(k).getDay());
      let work = !weekend,
        label = weekend ? "周末" : "工作日";
      if (holidays[k]) {
        work = false;
        label = holidays[k];
      }
      if (makeups.has(k)) {
        work = true;
        label = "调休补班";
      }
      if (struggleDays.has(k)) label = "奋斗日";
      if (day.kind === "work") {
        work = true;
        label = "工作日 · 手动";
      }
      if (day.kind === "rest") {
        work = false;
        label = "休息日 · 手动";
      }
      return {
        work,
        makeup: makeups.has(k),
        label,
        holiday: work ? "" : holidays[k] || "",
        weekend: weekend && !work,
      };
    }
    return {
      holidays,
      makeups,
      calendarSchedules,
      calendarKnown,
      calendarInfo,
    };
  })();

  // Frozen conversion source: assets/js/domain/records.js
  ("use strict");
  /** records domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkRecords = (() => {
    const { pad, timeMin } = WorkTimeValues;
    const { calendarInfo } = WorkCalendar;
    function actualRecord(day = {}) {
      if (day.actual) return { ...day.actual, type: "actual", manual: true };
      if (day.oa && day.oa.status === "complete")
        return { ...day.oa, type: "actual", manual: false };
      return null;
    }
    function effectiveRecord(day = {}, includeEstimate = false) {
      if (day.draft)
        return {
          ...day.draft,
          effectiveMinutes: null,
          type: "actual",
          manual: true,
        };
      const actual = actualRecord(day);
      if (actual && complete(actual)) return actual;
      if (includeEstimate && day.estimate)
        return {
          ...day.estimate,
          start: (day.oa && day.oa.start) || day.estimate.start,
          type: "estimate",
          manual: true,
        };
      return actual;
    }
    function complete(r) {
      if (!r) return false;
      if (r.effectiveMinutes !== null && r.effectiveMinutes !== undefined)
        return Number.isInteger(r.effectiveMinutes) && r.effectiveMinutes >= 0;
      const a = timeMin(r.start),
        b = timeMin(r.end);
      return a !== null && b !== null && b + (r.nextDay ? 1440 : 0) >= a;
    }
    /**
     * @param {WorkManualRecord|WorkOAObservation|null} r
     * @param {{breaks:WorkBreak[]}} settings
     * @returns {number|null} Effective minutes; null means incomplete, not zero.
     */
    function duration(r, settings) {
      if (!complete(r)) return null;
      if (r.effectiveMinutes !== null && r.effectiveMinutes !== undefined)
        return r.effectiveMinutes;
      const start = timeMin(r.start),
        end = timeMin(r.end) + (r.nextDay ? 1440 : 0),
        intervals = [];
      for (let offset = 0; offset <= 1440; offset += 1440)
        for (const rest of settings.breaks) {
          const a = Math.max(start, rest.start + offset),
            b = Math.min(end, rest.end + offset);
          if (b > a) intervals.push([a, b]);
        }
      intervals.sort((a, b) => a[0] - b[0]);
      let deduction = 0,
        left = null,
        right = null;
      for (const [a, b] of intervals) {
        if (left === null) {
          left = a;
          right = b;
        } else if (a <= right) right = Math.max(right, b);
        else {
          deduction += right - left;
          left = a;
          right = b;
        }
      }
      if (left !== null) deduction += right - left;
      return Math.max(0, end - start - deduction);
    }
    function inferWorkEnd(start, targetMinutes, breaks) {
      const startMinutes = timeMin(start);
      if (startMinutes === null) return null;
      for (let elapsed = 1; elapsed <= 1440 - startMinutes; elapsed++) {
        const absolute = startMinutes + elapsed,
          end = pad(Math.floor(absolute / 60)) + ":" + pad(absolute % 60);
        if (
          duration(
            { start, end, nextDay: false, effectiveMinutes: null },
            { breaks },
          ) >= targetMinutes
        )
          return end;
      }
      return null;
    }
    /**
     * @param {string} k YYYY-MM-DD
     * @param {WorkDay} day
     * @param {WorkSettings} settings
     * @param {boolean} includeEstimate Include manual filling held as estimate.
     */
    function calculate(k, day, settings, includeEstimate = false) {
      const r = effectiveRecord(day, includeEstimate),
        info = calendarInfo(k, day),
        leave = Math.min(
          settings.standardMinutes,
          Math.max(0, day.leaveMinutes || 0),
        );
      if (!settings.configured || !complete(r))
        return {
          record: r,
          minutes: null,
          overtime: null,
          attendance: 0,
          work: info.work,
        };
      const minutes = duration(r, settings);
      return {
        record: r,
        minutes,
        overtime: info.work
          ? minutes - settings.standardMinutes + leave
          : minutes,
        attendance: info.work
          ? (settings.standardMinutes - leave) / settings.standardMinutes
          : 0,
        work: info.work,
      };
    }
    return {
      actualRecord,
      effectiveRecord,
      complete,
      duration,
      inferWorkEnd,
      calculate,
    };
  })();

  // Frozen conversion source: assets/js/domain/schedule.js
  ("use strict");
  /** Date schedules are pure interval replacements, never layered overrides. */
  const WorkSchedule = (() => {
    const { validDate, localDate, dateKey, timeMin } = WorkTimeValues;
    function shiftDate(date, days) {
      const d = localDate(date);
      d.setDate(d.getDate() + days);
      const result = dateKey(d);
      if (!validDate(result)) throw Error("日期超出支持范围。");
      return result;
    }
    function scheduleForDate(state, date) {
      const range = (state.scheduleRanges || []).find(
        (r) => r.start <= date && (!r.end || date <= r.end),
      );
      return range ? { ...state.settings, ...range.schedule } : state.settings;
    }
    function scheduleError(path, message) {
      const error = Error(message + " [" + path + "]");
      error.path = path;
      error.userMessage = message;
      throw error;
    }
    function validateSchedule(input, path = "schedule") {
      const fail = (key, message) => scheduleError(path + "." + key, message);
      if (!input || typeof input !== "object" || Array.isArray(input))
        scheduleError(path, "作息格式无效。");
      if (timeMin(input.workStart) === null)
        fail("workStart", "标准上班时间无效。");
      if (
        timeMin(input.workEnd) === null ||
        timeMin(input.workEnd) <= timeMin(input.workStart)
      )
        fail("workEnd", "标准下班时间必须晚于上班时间。");
      if (!Array.isArray(input.breaks)) fail("breaks", "休息时段格式无效。");
      const breaks = Array.from(input.breaks, (rest, i) => {
        if (
          !rest ||
          !Number.isInteger(rest.start) ||
          rest.start < 0 ||
          rest.start >= 1440
        )
          fail("breaks[" + i + "].start", "休息开始时间无效。");
        if (
          !Number.isInteger(rest.end) ||
          rest.end <= rest.start ||
          rest.end > 1440
        )
          fail("breaks[" + i + "].end", "休息结束时间无效。");
        return { start: rest.start, end: rest.end };
      });
      const standardMinutes = WorkRecords.duration(
        {
          start: input.workStart,
          end: input.workEnd,
          nextDay: false,
          effectiveMinutes: null,
        },
        { breaks },
      );
      if (standardMinutes < 1)
        fail("standardMinutes", "扣除休息后标准工时必须大于0。");
      if (
        input.standardMinutes !== undefined &&
        input.standardMinutes !== standardMinutes
      )
        fail("standardMinutes", "标准工时与作息不一致。");
      return {
        workStart: input.workStart,
        workEnd: input.workEnd,
        breaks,
        standardMinutes,
      };
    }
    function scheduleSignature(schedule) {
      const rests = [...schedule.breaks].sort(
        (a, b) => a.start - b.start || a.end - b.end,
      );
      const merged = [];
      for (const rest of rests) {
        const last = merged.at(-1);
        if (last && rest.start <= last.end)
          last.end = Math.max(last.end, rest.end);
        else merged.push({ ...rest });
      }
      return JSON.stringify([
        schedule.workStart,
        schedule.workEnd,
        schedule.standardMinutes,
        merged,
      ]);
    }
    function validateScheduleRanges(ranges) {
      if (!Array.isArray(ranges))
        scheduleError("scheduleRanges", "作息区间格式无效。");
      let previous = null;
      return Array.from(ranges, (r, i) => {
        const path = "scheduleRanges[" + i + "]";
        if (!r || !validDate(r.start))
          scheduleError(path + ".start", "作息开始日期无效。");
        if (r.end !== null && (!validDate(r.end) || r.end < r.start))
          scheduleError(path + ".end", "作息结束日期无效。");
        if (previous && (!previous.end || r.start <= previous.end))
          scheduleError(path + ".start", "作息区间必须有序且不能重叠。");
        const result = {
          start: r.start,
          end: r.end,
          schedule: validateSchedule(r.schedule, path + ".schedule"),
        };
        previous = result;
        return result;
      });
    }
    function applyScheduleRange(state, schedule, start, end) {
      const clean = validateSchedule(schedule);
      if (
        start !== null &&
        (!validDate(start) ||
          (end !== null && (!validDate(end) || end < start)))
      )
        throw Error("请选择有效的起止日期。");
      if (start === null && end !== null)
        throw Error("全部日期不应填写结束日期。");
      const candidate = {
        ...state,
        settings: { ...state.settings, configured: true },
        scheduleRanges: [],
      };
      if (start === null) Object.assign(candidate.settings, clean);
      else {
        for (const r of state.scheduleRanges || []) {
          if ((r.end && r.end < start) || (end && r.start > end))
            candidate.scheduleRanges.push(r);
          else {
            if (r.start < start)
              candidate.scheduleRanges.push({
                ...r,
                end: shiftDate(start, -1),
              });
            if (end && end !== "9999-12-31" && (!r.end || r.end > end))
              candidate.scheduleRanges.push({ ...r, start: shiftDate(end, 1) });
          }
        }
        candidate.scheduleRanges.push({ start, end, schedule: clean });
        candidate.scheduleRanges.sort((a, b) => a.start.localeCompare(b.start));
        const merged = [];
        for (const r of candidate.scheduleRanges) {
          if (
            scheduleSignature(r.schedule) ===
            scheduleSignature(candidate.settings)
          )
            continue;
          const last = merged.at(-1);
          if (
            last &&
            last.end &&
            last.end !== "9999-12-31" &&
            shiftDate(last.end, 1) === r.start &&
            scheduleSignature(last.schedule) === scheduleSignature(r.schedule)
          )
            last.end = r.end;
          else merged.push({ ...r });
        }
        candidate.scheduleRanges = merged;
      }
      const conflicts = Object.entries(candidate.days)
        .filter(
          ([date, day]) =>
            (day.leaveMinutes || 0) >
            scheduleForDate(candidate, date).standardMinutes,
        )
        .map(([date]) => date)
        .sort();
      if (conflicts.length)
        throw Error(
          "以下日期请假时长超过新标准工时，请先修正：" + conflicts.join("、"),
        );
      return candidate;
    }
    function scheduleRangeForChoice(choice, today, start, end) {
      if (!validDate(today)) throw Error("当前日期无效。");
      if (choice === "all") return { start: null, end: null };
      if (choice === "future") return { start: today, end: null };
      if (choice === "week") return { start: today, end: shiftDate(today, 6) };
      if (choice === "month") {
        const d = localDate(today);
        d.setMonth(d.getMonth() + 1, 0);
        return { start: today, end: dateKey(d) };
      }
      if (
        choice !== "custom" ||
        !validDate(start) ||
        (end !== null && (!validDate(end) || end < start))
      )
        throw Error("请选择有效的起止日期。");
      return { start, end };
    }
    return {
      scheduleForDate,
      validateSchedule,
      validateScheduleRanges,
      scheduleSignature,
      applyScheduleRange,
      scheduleRangeForChoice,
    };
  })();

  // Frozen conversion source: assets/js/domain/statistics.js
  ("use strict");
  /** statistics domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkStatistics = (() => {
    const {
      dateKey,
      localDate,
      validDate,
      timeMin,
      businessDate,
      businessMinutes,
    } = WorkTimeValues;
    const { DEFAULT_START } = WorkState;
    const { calendarInfo } = WorkCalendar;
    const { effectiveRecord, complete, duration, calculate } = WorkRecords;
    function oaStaleness(state, today = businessDate()) {
      const latest = Object.keys(state.days)
        .filter((k) => validDate(k) && k <= today && state.days[k].oa)
        .sort()
        .pop();
      if (!latest) return null;
      const dayNumber = (k) => {
        const [y, m, d] = k.split("-").map(Number);
        return Date.UTC(y, m - 1, d) / 86400000;
      };
      const days = dayNumber(today) - dayNumber(latest);
      return { date: latest, days, stale: days >= 3 };
    }
    const { scheduleForDate } = WorkSchedule;
    function attendanceHoursThrough(state, start, end, endDay) {
      if (!validDate(start) || !validDate(end) || start > end) return null;
      let expectedMinutes = 0,
        workedMinutes = 0,
        expectedDays = 0,
        workedDays = 0;
      const cursor = localDate(start);
      while (dateKey(cursor) <= end) {
        const k = dateKey(cursor),
          day = k === end && endDay ? endDay : state.days[k] || {},
          schedule = scheduleForDate(state, k);
        if (calendarInfo(k, day).work) {
          const minutes = Math.max(
            0,
            schedule.standardMinutes - (day.leaveMinutes || 0),
          );
          expectedMinutes += minutes;
          expectedDays += minutes / schedule.standardMinutes;
        }
        const actual = calculate(k, day, schedule, true);
        if (actual.minutes !== null) {
          workedMinutes += actual.minutes;
          workedDays += actual.minutes / schedule.standardMinutes;
        }
        cursor.setDate(cursor.getDate() + 1);
      }
      return { expectedMinutes, workedMinutes, expectedDays, workedDays };
    }
    function cumulativeAverageOvertime(state, start, end, endDay) {
      const values = {};
      if (!validDate(start) || !validDate(end) || start > end) return values;
      // Denominator includes scheduled attendance only for complete workday records.
      let scheduledMinutes = 0,
        workOvertimeMinutes = 0,
        attendance = 0;
      const cursor = localDate(start);
      while (dateKey(cursor) <= end) {
        const k = dateKey(cursor),
          day = k === end && endDay ? endDay : state.days[k] || {},
          schedule = scheduleForDate(state, k),
          info = calendarInfo(k, day),
          result = calculate(k, day, schedule, true),
          pending =
            info.work &&
            (day.leaveMinutes || 0) <
              scheduleForDate(state, k).standardMinutes &&
            result.minutes === null;
        if (state.settings.configured && info.work) {
          if (result.minutes !== null) {
            scheduledMinutes += Math.max(
              0,
              scheduleForDate(state, k).standardMinutes -
                (day.leaveMinutes || 0),
            );
            workOvertimeMinutes += result.overtime;
            attendance += result.attendance;
          }
        }
        values[k] = {
          scheduledMinutes,
          attendance,
          workOvertimeMinutes,
          pending,
          averageMinutes:
            attendance && !pending ? workOvertimeMinutes / attendance : null,
        };
        cursor.setDate(cursor.getDate() + 1);
      }
      return values;
    }
    function pendingWorkdays(
      state,
      start,
      end,
      asOf = businessDate(),
      now = new Date(),
    ) {
      if (!validDate(start) || !validDate(end) || !validDate(asOf)) return 0;
      const last = end < asOf ? end : asOf;
      if (start > last) return 0;
      const currentDate = businessDate(now),
        beforeWorkStart =
          asOf === currentDate &&
          businessMinutes(now) <
            timeMin(
              scheduleForDate(state, currentDate).workStart || DEFAULT_START,
            );
      let count = 0;
      const cursor = localDate(start);
      while (dateKey(cursor) <= last) {
        const k = dateKey(cursor),
          day = state.days[k] || {};
        if (
          !(k === asOf && beforeWorkStart) &&
          calendarInfo(k, day).work &&
          (day.leaveMinutes || 0) < scheduleForDate(state, k).standardMinutes &&
          !complete(effectiveRecord(day, true))
        )
          count++;
        cursor.setDate(cursor.getDate() + 1);
      }
      return count;
    }
    function summary(state, start, end, includeEstimate = true) {
      const out = {
        total: 0,
        workOvertime: 0,
        restOvertime: 0,
        attendance: 0,
        completeDays: 0,
        pending: 0,
        estimatedDays: 0,
        average: null,
      };
      for (const [k, day] of Object.entries(state.days)) {
        if (k < start || k > end) continue;
        const c = calculate(k, day, scheduleForDate(state, k), includeEstimate);
        if (
          day.oa &&
          day.oa.status === "pending" &&
          !complete(effectiveRecord(day, true))
        )
          out.pending++;
        if (c.minutes === null) continue;
        out.total += c.minutes;
        out.completeDays++;
        out.estimatedDays += c.record.type === "estimate" ? 1 : 0;
        if (c.work) {
          out.workOvertime += c.overtime;
          out.attendance += c.attendance;
        } else out.restOvertime += c.overtime;
      }
      if (out.attendance > 0) out.average = out.workOvertime / out.attendance;
      return out;
    }
    function countRestOvertimeDays(state, start, end) {
      let actualDays = 0,
        plannedDays = 0;
      for (const [date, day] of Object.entries(state.days)) {
        if (date < start || date > end || calendarInfo(date, day).work)
          continue;
        const record = effectiveRecord(day, true),
          worked =
            complete(record) &&
            duration(record, scheduleForDate(state, date)) > 0;
        if (worked) actualDays++;
        else if (day.plannedOvertime) plannedDays++;
      }
      return { actualDays, plannedDays, totalDays: actualDays + plannedDays };
    }
    function selectOvertimeRequirement(state, start, end) {
      const counts = countRestOvertimeDays(state, start, end),
        tier = Math.min(4, counts.totalDays),
        requirements = state.overtimeRequirements || [
          state.targetAverageMinutes ?? 120,
          null,
          null,
          null,
          null,
        ];
      return { ...counts, tier, targetMinutes: requirements[tier] };
    }
    function targetPace(
      state,
      start,
      end,
      asOf,
      targetMinutes,
      derivedSummary,
    ) {
      if (
        !validDate(start) ||
        !validDate(end) ||
        !validDate(asOf) ||
        start > end ||
        !Number.isFinite(targetMinutes) ||
        targetMinutes < 0
      )
        return null;
      const earned = (derivedSummary || summary(state, start, end))
        .workOvertime;
      let plannedDays = 0,
        remainingDays = 0;
      const cursor = localDate(start);
      while (dateKey(cursor) <= end) {
        const k = dateKey(cursor),
          day = state.days[k] || {};
        if (calendarInfo(k, day).work) {
          const standard = scheduleForDate(state, k).standardMinutes;
          const portion =
            Math.max(
              0,
              standard - Math.min(standard, Math.max(0, day.leaveMinutes || 0)),
            ) / standard;
          plannedDays += portion;
          if (k >= asOf && !complete(effectiveRecord(day, true)))
            remainingDays += portion;
        }
        cursor.setDate(cursor.getDate() + 1);
      }
      const difference = targetMinutes * plannedDays - earned,
        shortfall = Math.max(0, difference),
        rawRequiredPerDay = remainingDays ? difference / remainingDays : null;
      return {
        plannedDays,
        remainingDays,
        earned,
        shortfall,
        difference,
        rawRequiredPerDay,
        requiredPerDay: rawRequiredPerDay,
      };
    }
    return {
      oaStaleness,
      attendanceHoursThrough,
      cumulativeAverageOvertime,
      pendingWorkdays,
      summary,
      countRestOvertimeDays,
      selectOvertimeRequirement,
      targetPace,
    };
  })();

  // Frozen conversion source: assets/js/domain/observations.js
  ("use strict");
  /** observations domain. No DOM or storage access. Loaded as an ordered classic script for file://. */
  const WorkObservations = (() => {
    const { pad, localDate, validDate, timeMin } = WorkTimeValues;
    function parseText(raw, year, source = "粘贴文本") {
      const warnings = [],
        records = [];
      if (!Number.isInteger(year) || year < 1900 || year > 9999)
        return { records, warnings: ["年份必须为 1900–9999 的整数。"] };
      const lines = raw
        .replace(/^\uFEFF/, "")
        .split(/\r?\n/)
        .map((x) => x.trim())
        .filter(Boolean);
      let block = null;
      function finish() {
        if (!block) return;
        const k = year + "-" + pad(block.month) + "-" + pad(block.day);
        if (!validDate(k)) {
          warnings.push(source + "：无效日期 " + block.month + "/" + block.day);
          return;
        }
        const weekday = block.lines.find((x) =>
          /^(周|星期)[一二三四五六日天]$/.test(x),
        );
        if (weekday) {
          const w = "日一二三四五六"[localDate(k).getDay()];
          if (!weekday.endsWith(w) && !(w === "日" && weekday.endsWith("天")))
            warnings.push(
              source + "：" + k + " 的星期与文本不一致，请检查年份。",
            );
        }
        const times = block.lines.filter((x) => timeMin(x) !== null),
          off = block.lines.some((x) => /^[-—–]{2,}$/.test(x));
        if (times.length > 2) {
          warnings.push(
            source + "：" + k + " 有超过两次打卡，需手动核查；该日未导入。",
          );
          return;
        }
        if (!times.length && !off) {
          warnings.push(source + "：" + k + " 未识别到打卡或 --，该日未导入。");
          return;
        }
        const record = {
          date: k,
          start: times[0] || "",
          end: times[1] || "",
          nextDay: false,
          status:
            times.length === 2 ? "complete" : times.length ? "pending" : "off",
          source,
          raw: [block.header, ...block.lines].join("\n"),
        };
        if (times.length === 2 && timeMin(times[1]) < timeMin(times[0])) {
          record.status = "pending";
          warnings.push(
            source + "：" + k + " 下班早于上班，请在当天勾选“次日下班”后补录。",
          );
        }
        if (off && times.length)
          warnings.push(source + "：" + k + " 同时含 -- 与打卡，以打卡为准。");
        records.push(record);
      }
      for (const line of lines) {
        const m = /^(\d{1,2})[\/-](\d{1,2})$/.exec(line);
        if (m) {
          finish();
          block = {
            month: Number(m[1]),
            day: Number(m[2]),
            header: line,
            lines: [],
          };
        } else if (block) block.lines.push(line);
      }
      finish();
      if (!records.length && !warnings.length)
        warnings.push(source + "：未识别到 MM/DD 日期记录。");
      return { records, warnings };
    }
    function mergeObservation(old, incoming) {
      if (!old) return { record: incoming, action: "新增" };
      if (
        ["start", "end", "nextDay", "status"].every(
          (k) => old[k] === incoming[k],
        )
      )
        return { record: old, action: "重复，保持不变" };
      if (old.status === "complete" && incoming.status !== "complete")
        return { record: old, action: "保留已有完整记录" };
      if (old.status === "complete" && incoming.status === "complete")
        return { record: incoming, action: "完整打卡冲突", conflict: true };
      if (incoming.status === "complete")
        return { record: incoming, action: "补全打卡" };
      if (old.start && !incoming.start)
        return { record: old, action: "保留已有上班打卡" };
      return { record: incoming, action: "更新记录" };
    }
    function applyObservation(state, record, importId) {
      const day = state.days[record.date] || (state.days[record.date] = {});
      const result = mergeObservation(day.oa, record);
      if (result.record !== day.oa) day.oa = { ...result.record, importId };
      if (day.oa.status === "complete") delete day.estimate;
      return result;
    }
    function importRecords(log) {
      if (Array.isArray(log.records)) return log.records;
      return log.sources.flatMap(
        (source) => parseText(source.raw, log.year, source.name).records,
      );
    }
    function deleteImport(state, id) {
      if (!state.imports.some((log) => log.id === id))
        return { removed: false, affected: 0, restored: 0, cleared: 0 };
      const remaining = state.imports.filter((log) => log.id !== id),
        rebuilt = {};
      for (const log of remaining)
        for (const record of importRecords(log)) {
          const result = mergeObservation(rebuilt[record.date], record);
          if (result.record !== rebuilt[record.date])
            rebuilt[record.date] = { ...result.record, importId: log.id };
        }
      const result = { removed: true, affected: 0, restored: 0, cleared: 0 };
      for (const [date, day] of Object.entries(state.days)) {
        if (!day.oa || day.oa.importId !== id) continue;
        result.affected++;
        if (rebuilt[date]) {
          day.oa = rebuilt[date];
          result.restored++;
        } else {
          delete day.oa;
          result.cleared++;
        }
        if (
          !day.oa &&
          !day.actual &&
          !day.estimate &&
          !day.draft &&
          !day.kind &&
          !day.leaveMinutes &&
          !day.note &&
          !day.plannedOvertime
        )
          delete state.days[date];
      }
      state.imports = remaining;
      return result;
    }
    return {
      parseText,
      mergeObservation,
      applyObservation,
      importRecords,
      deleteImport,
    };
  })();

  // Frozen conversion source: assets/js/domain/validation.js
  ("use strict");
  const WorkValidation = (() => {
    const { validDate, timeMin } = WorkTimeValues,
      { DEFAULT_START, SCHEMA, defaultState } = WorkState,
      { complete, duration, inferWorkEnd } = WorkRecords;
    const object = (value) =>
      value !== null && typeof value === "object" && !Array.isArray(value);
    function fail(path, message) {
      const error = Error(message + " [" + path + "]");
      error.name = "BackupValidationError";
      error.path = path;
      error.userMessage = message;
      throw error;
    }
    function clock(value, path, allowEmpty = false) {
      if (
        typeof value !== "string" ||
        ((value !== "" || !allowEmpty) && timeMin(value) === null)
      )
        fail(path, "请填写有效的 HH:MM 时间。");
    }
    function text(value, path) {
      if (
        value != null &&
        !["string", "number", "boolean"].includes(typeof value)
      )
        fail(path, "备份中的文本字段无效。");
      return String(value || "");
    }
    function validateOvertimeRequirements(
      values,
      path = "overtimeRequirements",
    ) {
      const message = "加班条件须为五档 0–24 小时要求，最低要求不能为空。";
      if (!Array.isArray(values) || values.length !== 5) fail(path, message);
      if (values[0] === null) fail(path + "[0]", message);
      Array.from(values, (value, index) => {
        if (
          value !== null &&
          (!Number.isFinite(value) || value < 0 || value > 1440)
        )
          fail(path + "[" + index + "]", message);
      });
      return [...values];
    }
    function validateImportRecord(record, year, path = "importRecord") {
      if (!object(record)) fail(path, "备份中的导入打卡记录无效。");
      if (
        typeof record.date !== "string" ||
        !validDate(record.date) ||
        Number(record.date.slice(0, 4)) !== year
      )
        fail(path + ".date", "备份中的导入打卡日期无效。");
      clock(record.start, path + ".start", true);
      clock(record.end, path + ".end", true);
      if (typeof record.nextDay !== "boolean")
        fail(path + ".nextDay", "备份中的次日下班标记无效。");
      if (!["complete", "pending", "off"].includes(record.status))
        fail(path + ".status", "备份中的导入打卡状态无效。");
      if (record.effectiveMinutes != null)
        fail(path + ".effectiveMinutes", "导入原始打卡不支持修正工时。");
      if (
        record.status === "complete" &&
        (timeMin(record.start) === null ||
          timeMin(record.end) === null ||
          timeMin(record.end) + (record.nextDay ? 1440 : 0) <
            timeMin(record.start))
      )
        fail(path + ".end", "备份中的完整导入记录无效。");
      return {
        date: record.date,
        start: record.start,
        end: record.end,
        nextDay: record.nextDay,
        status: record.status,
        source: text(record.source, path + ".source"),
        raw: text(record.raw, path + ".raw"),
      };
    }
    function validateTimeTemplate(template, path = "timeTemplate") {
      if (!object(template)) fail(path, "模板标识无效。");
      if (
        typeof template.id !== "string" ||
        !template.id.trim() ||
        template.id.length > 100
      )
        fail(path + ".id", "模板标识无效。");
      if (
        typeof template.name !== "string" ||
        !template.name.trim() ||
        template.name.trim().length > 30
      )
        fail(path + ".name", "模板名称须为 1–30 个字符。");
      clock(template.start, path + ".start");
      clock(template.end, path + ".end");
      if (typeof template.nextDay !== "boolean")
        fail(path + ".nextDay", "请填写完整的上下班时间。");
      if (
        timeMin(template.end) + (template.nextDay ? 1440 : 0) <
        timeMin(template.start)
      )
        fail(path + ".end", "下班早于上班，跨午夜请勾选“次日下班”。");
      return {
        id: template.id,
        name: template.name.trim(),
        start: template.start,
        end: template.end,
        nextDay: template.nextDay,
      };
    }
    function validateDay(key, day, standard) {
      const path = "days." + key;
      if (!validDate(key) || !object(day)) fail(path, "备份中的日期记录无效。");
      if (day.kind !== undefined && !["work", "rest"].includes(day.kind))
        fail(path + ".kind", key + " 的日历属性无效。");
      if (
        day.leaveMinutes !== undefined &&
        (!Number.isInteger(day.leaveMinutes) ||
          day.leaveMinutes < 0 ||
          day.leaveMinutes > standard)
      )
        fail(
          path + ".leaveMinutes",
          key + " 的请假时长无效，不能超过规范化后的标准工时。",
        );
      const clean = {};
      if (day.plannedOvertime !== undefined) {
        if (typeof day.plannedOvertime !== "boolean")
          fail(path + ".plannedOvertime", key + " 的计划加班标记无效。");
        clean.plannedOvertime = day.plannedOvertime;
      }
      if (day.kind) clean.kind = day.kind;
      if (day.note !== undefined) {
        if (typeof day.note !== "string")
          fail(path + ".note", "备注格式无效。");
        clean.note = day.note;
      }
      if (day.leaveMinutes !== undefined) clean.leaveMinutes = day.leaveMinutes;
      for (const name of ["oa", "actual", "estimate", "draft"]) {
        const record = day[name],
          field = path + "." + name;
        // Null represents an absent record in legacy backups; false/0/string are malformed.
        if (record === undefined || record === null) continue;
        if (!object(record)) fail(field, key + " 的打卡记录无效。");
        clock(record.start, field + ".start", true);
        clock(record.end, field + ".end", true);
        if (typeof record.nextDay !== "boolean")
          fail(field + ".nextDay", key + " 的次日下班标记无效。");
        if (
          record.effectiveMinutes !== undefined &&
          record.effectiveMinutes !== null &&
          (!Number.isInteger(record.effectiveMinutes) ||
            record.effectiveMinutes < 0 ||
            record.effectiveMinutes > 2880)
        )
          fail(field + ".effectiveMinutes", key + " 的修正工时无效。");
        if (name === "oa" && record.effectiveMinutes != null)
          fail(
            field + ".effectiveMinutes",
            key + " 的 OA 原始打卡不支持修正工时，请使用手动记录。",
          );
        if (
          name === "oa" &&
          !["complete", "pending", "off"].includes(record.status)
        )
          fail(field + ".status", key + " 的 OA 状态无效。");
        if (
          ((name === "oa" && record.status === "complete") ||
            name === "actual" ||
            name === "estimate") &&
          !complete(record)
        )
          fail(field + ".end", key + " 的完整工时记录无效。");
        const result = {
          start: record.start,
          end: record.end,
          nextDay: record.nextDay,
        };
        if (name === "oa") {
          if (record.date !== key) fail(field + ".date", "OA 日期不匹配。");
          Object.assign(result, {
            date: key,
            status: record.status,
            source: text(record.source, field + ".source"),
            raw: text(record.raw, field + ".raw"),
            importId: text(record.importId, field + ".importId"),
          });
        } else
          result.effectiveMinutes =
            record.effectiveMinutes === undefined
              ? null
              : record.effectiveMinutes;
        clean[name] = result;
      }
      return clean;
    }
    /** @param {*} input Untrusted decoded backup. @returns {WorkStateData} New normalized state; errors contain path and userMessage. */
    function validateBackup(input) {
      if (!object(input)) fail("$", "不是支持的工作记录备份文件。");
      if (input.schemaVersion !== 1 && input.schemaVersion !== SCHEMA)
        fail("schemaVersion", "不是支持的工作记录备份文件。");
      if (!object(input.settings))
        fail("settings", "备份中的工作时间设置无效。");
      if (!object(input.days)) fail("days", "备份中的日期记录无效。");
      if (!Array.isArray(input.imports))
        fail("imports", "备份中的导入历史无效。");
      const settings = input.settings;
      if (typeof settings.configured !== "boolean")
        fail("settings.configured", "备份中的工作时间设置无效。");
      if (
        !Number.isInteger(settings.standardMinutes) ||
        settings.standardMinutes <= 0 ||
        settings.standardMinutes > 1440
      )
        fail("settings.standardMinutes", "备份中的工作时间设置无效。");
      if (!Array.isArray(settings.breaks))
        fail("settings.breaks", "备份中的休息时段无效。");
      const breaks = Array.from(settings.breaks, (rest, index) => {
        const path = "settings.breaks[" + index + "]";
        if (!object(rest)) fail(path, "备份中的休息时段无效。");
        if (
          !Number.isInteger(rest.start) ||
          rest.start < 0 ||
          rest.start >= 1440
        )
          fail(path + ".start", "备份中的休息时段无效。");
        if (
          !Number.isInteger(rest.end) ||
          rest.end > 1440 ||
          rest.end <= rest.start
        )
          fail(path + ".end", "备份中的休息时段无效。");
        return { start: rest.start, end: rest.end };
      });
      for (const key of ["workStart", "workEnd"])
        if (settings[key] !== undefined && settings[key] !== "")
          clock(settings[key], "settings." + key);
      const workStart = settings.workStart || DEFAULT_START,
        workEnd =
          settings.workEnd ||
          inferWorkEnd(workStart, settings.standardMinutes, breaks);
      if (!workEnd || timeMin(workEnd) <= timeMin(workStart))
        fail("settings.workEnd", "备份中的标准上下班时间无效。");
      const standard = duration(
        {
          start: workStart,
          end: workEnd,
          nextDay: false,
          effectiveMinutes: null,
        },
        { breaks },
      );
      if (!Number.isInteger(standard) || standard <= 0)
        fail("settings.standardMinutes", "备份中的标准工时区间无效。");
      if (
        settings.employmentDate !== undefined &&
        (typeof settings.employmentDate !== "string" ||
          (settings.employmentDate && !validDate(settings.employmentDate)))
      )
        fail("settings.employmentDate", "备份中的入职日期无效。");
      if (
        settings.workCity !== undefined &&
        (typeof settings.workCity !== "string" || settings.workCity.length > 64)
      )
        fail("settings.workCity", "备份中的工作城市须为不超过64字的文本。");
      const clean = defaultState();
      clean.scheduleDefaultsVersion =
        input.scheduleDefaultsVersion === 1 ? 1 : 0;
      clean.settings = {
        configured: settings.configured,
        workStart,
        workEnd,
        standardMinutes: standard,
        breaks,
        employmentDate: settings.employmentDate || "",
        workCity: settings.workCity || "",
      };
      clean.scheduleRanges =
        input.schemaVersion === 1
          ? []
          : WorkSchedule.validateScheduleRanges(input.scheduleRanges);
      if (input.oaUrl !== undefined) {
        if (
          typeof input.oaUrl !== "string" ||
          (input.oaUrl &&
            !/^https?:\/\/[^\s/]+(?:[/?#][^\s]*)?$/i.test(input.oaUrl))
        )
          fail("oaUrl", "备份中的 OA 链接无效。");
        clean.oaUrl = input.oaUrl;
      }
      if (input.targetAverageMinutes !== undefined) {
        if (
          !Number.isFinite(input.targetAverageMinutes) ||
          input.targetAverageMinutes < 0 ||
          input.targetAverageMinutes > 1440
        )
          fail("targetAverageMinutes", "备份中的月均加班目标无效。");
        clean.targetAverageMinutes = input.targetAverageMinutes;
      }
      clean.overtimeRequirements =
        input.overtimeRequirements === undefined
          ? [clean.targetAverageMinutes, null, null, null, null]
          : validateOvertimeRequirements(input.overtimeRequirements);
      for (const [key, day] of Object.entries(input.days))
        clean.days[key] = validateDay(
          key,
          day,
          WorkSchedule.scheduleForDate(clean, key).standardMinutes,
        );
      const importIds = new Set();
      clean.imports = Array.from(input.imports, (log, index) => {
        const path = "imports[" + index + "]";
        if (!object(log)) fail(path, "备份中的导入历史无效。");
        if (typeof log.id !== "string" || !log.id || importIds.has(log.id))
          fail(path + ".id", "备份中的导入历史标识无效或重复。");
        if (typeof log.at !== "string" || !Number.isFinite(Date.parse(log.at)))
          fail(path + ".at", "备份中的导入时间无效。");
        if (!Number.isInteger(log.year) || log.year < 1900 || log.year > 9999)
          fail(path + ".year", "备份中的导入年份无效。");
        if (!Array.isArray(log.sources))
          fail(path + ".sources", "备份中的导入来源无效。");
        const sources = Array.from(log.sources, (source, sourceIndex) => {
          const field = path + ".sources[" + sourceIndex + "]";
          if (!object(source)) fail(field, "备份中的导入来源无效。");
          return {
            name: text(source.name, field + ".name"),
            raw: text(source.raw, field + ".raw"),
          };
        });
        if (
          log.count != null &&
          !["number", "string"].includes(typeof log.count)
        )
          fail(path + ".count", "备份中的导入数量无效。");
        const count = log.count == null ? 0 : Number(log.count);
        if (
          log.count != null &&
          (!["number", "string"].includes(typeof log.count) ||
            !Number.isInteger(count) ||
            count < 0)
        )
          fail(path + ".count", "备份中的导入数量无效。");
        importIds.add(log.id);
        const result = {
          id: log.id,
          at: log.at,
          year: log.year,
          sources,
          count,
        };
        if (log.records !== undefined) {
          if (!Array.isArray(log.records))
            fail(path + ".records", "备份中的导入打卡记录无效。");
          result.records = Array.from(log.records, (record, recordIndex) =>
            validateImportRecord(
              record,
              log.year,
              path + ".records[" + recordIndex + "]",
            ),
          );
        }
        return result;
      });
      if (
        input.timeTemplates !== undefined &&
        !Array.isArray(input.timeTemplates)
      )
        fail("timeTemplates", "备份中的时间模板无效。");
      const templateIds = new Set();
      clean.timeTemplates = Array.from(
        input.timeTemplates || [],
        (template, index) => {
          const path = "timeTemplates[" + index + "]",
            result = validateTimeTemplate(template, path);
          if (templateIds.has(result.id))
            fail(path + ".id", "备份中有重复的模板标识。");
          templateIds.add(result.id);
          return result;
        },
      );
      if (input.pageTheme !== undefined) {
        if (
          !["green", "blue", "purple", "orange", "rose", "slate"].includes(
            input.pageTheme,
          )
        )
          fail("pageTheme", "备份中的页面主题无效。");
        clean.pageTheme = input.pageTheme;
      }
      return clean;
    }
    return {
      validateOvertimeRequirements,
      validateImportRecord,
      validateTimeTemplate,
      validateBackup,
    };
  })();

  // Frozen conversion source: assets/js/core.js
  ("use strict");
  /** Stable public API. Domain modules load first; see index.html. */
  const WorkTime = (() => {
    const {
      pad,
      dateKey,
      businessDate,
      businessMinutes,
      localDate,
      validDate,
      timeMin,
      breakMin,
      formatMinutes,
      hours,
    } = WorkTimeValues;
    const { DEFAULT_START, DEFAULT_END, SCHEMA, KEY, defaultState } = WorkState;
    const { applyScheduleDefaults } = WorkMigrations;
    const { calendarKnown, calendarInfo } = WorkCalendar;
    const {
      scheduleForDate,
      validateSchedule,
      validateScheduleRanges,
      scheduleSignature,
      applyScheduleRange,
      scheduleRangeForChoice,
    } = WorkSchedule;
    const { actualRecord, effectiveRecord, complete, duration, calculate } =
      WorkRecords;
    const {
      oaStaleness,
      attendanceHoursThrough,
      cumulativeAverageOvertime,
      pendingWorkdays,
      summary,
      countRestOvertimeDays,
      selectOvertimeRequirement,
      targetPace,
    } = WorkStatistics;
    const {
      parseText,
      mergeObservation,
      applyObservation,
      importRecords,
      deleteImport,
    } = WorkObservations;
    const {
      validateOvertimeRequirements,
      validateTimeTemplate,
      validateBackup,
    } = WorkValidation;
    return {
      scheduleForDate,
      validateSchedule,
      validateScheduleRanges,
      scheduleSignature,
      applyScheduleRange,
      scheduleRangeForChoice,
      calendarKnown,
      oaStaleness,
      validateOvertimeRequirements,
      countRestOvertimeDays,
      selectOvertimeRequirement,
      attendanceHoursThrough,
      targetPace,
      cumulativeAverageOvertime,
      pendingWorkdays,
      importRecords,
      deleteImport,
      validateTimeTemplate,
      DEFAULT_START,
      DEFAULT_END,
      applyScheduleDefaults,
      SCHEMA,
      KEY,
      pad,
      dateKey,
      businessDate,
      businessMinutes,
      localDate,
      validDate,
      timeMin,
      breakMin,
      formatMinutes,
      hours,
      defaultState,
      calendarInfo,
      parseText,
      mergeObservation,
      actualRecord,
      effectiveRecord,
      complete,
      duration,
      calculate,
      summary,
      applyObservation,
      validateBackup,
    };
  })();

  return { core: WorkTime, validate: WorkValidation.validateBackup };
})();
